<?php include("includes/header.php") ?>


    <div class="sectiune1c py-4">
            <div class="row justify-content-center">
                <div class = "col-6 ps-5">
                        <h1 class="text-start">Contact</h1>
                        <p class="text-start">Telefon: 0721266000</p>
                        <p class="text-start">Email: exemplu@gmail.com</p>
                        <p class="text-start">Adresa: Str. Cartofului, nr. 813</p>
                        <hr>
                        <h2 class="text-start">Robert Muresan</h2>
                        <p class="text-start">Telefon: 0721266000</p>
                        <p class="text-start">Email: exemplu@gmail.com</p>
                        <p class="text-start">Adresa: Str. Cartofului, nr. 813</p>
                        
                </div>
                <div class = "col-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2825.187805318444!2d25.44931541552865!3d44.91951617909829!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40b2f5c5eaf6a2d7%3A0x3fe55f4dc00dad61!2sCASA%20CARTOFULUI!5e0!3m2!1sen!2sro!4v1664722811520!5m2!1sen!2sro" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                    
                </div>
            </div>

        </div>
    </div>  
    
    
    


    <?php include("includes/footer.php") ?>

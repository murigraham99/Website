<footer class="footer">
        <img class = "logo" src = "image.png">
        <br>
       <form class="pb-3">
            <label class="pb-1">Aboneaza-te la newsletter!</label>
            <div class="container">
                    <div class="row">
                        <div class="col-md-4 m-auto">
                        <div class="input-group m-auto" >
                            <input type="text" class="form-control" placeholder="Adresa de e-mail" aria-label="Input group example" aria-describedby="btnGroupAddon2">
                            <button class ="btn btn-primary" type="button" id="btnGroupAddon2">Trimite</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <p>
            <?php echo "©". date("Y") . " Toate drepturile rezervate!" ?>

    </footer>

</body>
</html>
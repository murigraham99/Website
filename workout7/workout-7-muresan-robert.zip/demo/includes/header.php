<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel ="stylesheet" href="boots/boot/css/bootstrap.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <title>Test Site</title>
</head>
<body>
    <div class = "header">
        <div class="item_1">
            <ul class = "menu">
                <li><a href ="index.php">Home</a></li>
                <li><a href ="despre-noi.php">Despre noi</a></li>
                <li><a href ="contact.php">Contact</a></li>
            </ul>
         </div>

         <div class="item_2">
            <a class="phone" href="">📞</a>
         </div>
    </div>

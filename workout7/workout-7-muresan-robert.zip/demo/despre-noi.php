<?php include("includes/header.php") ?>


    <div class="sectiune1dn py-4">
            <div class="row justify-content-center">
                <div class = "col-10 text-center">
                        <h1 class="text-start">Despre noi</h1>
                        <p class="text-start">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent risus diam, feugiat quis pretium quis, eleifend eget erat. Nulla lobortis dui vitae cursus placerat. Fusce laoreet mi vel auctor imperdiet. Nulla vitae tempor enim. Ut aliquam lacus tortor, id finibus nulla porta in. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</h2>
                        <p class="text-start">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent risus diam, feugiat quis pretium quis, eleifend eget erat. Nulla lobortis dui vitae cursus placerat. Fusce laoreet mi vel auctor imperdiet. Nulla vitae tempor enim. Ut aliquam lacus tortor, id finibus nulla porta in. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                        <p class="text-start">
                            <a class="btn btn-outline-primary" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Citește mai mult</a>
                           
                        </p>
                        <div class="collapse" id="collapseExample">
                        <div class="card card-body">
                            <p class="text-start">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent risus diam, feugiat quis pretium quis, eleifend eget erat. Nulla lobortis dui vitae cursus placerat. Fusce laoreet mi vel auctor imperdiet. Nulla vitae tempor enim. Ut aliquam lacus tortor, id finibus nulla porta in. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p> 
                        </div>
                        </div>
                </div>
            </div>

        </div>
    </div>  
    
    <div class="sectiune2dn py-4">
        <div class="row justify-content-center">
            <div class = "col-10 text-center">
                    <h2 class="text-start">Echipa</h2>
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div style="background-image: url(https://images.generated.photos/UyXmRYCsz9Xxs3AmL5A3zDGD4t0YFrAcWlNhptn3omQ/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy90cmFu/c3BhcmVudF92My92/M18wNTEwNzMzLnBu/Zw.png)" class="card-img-top poza-card"></div>
                            <div class="card-body">
                              <h5 class="card-title">Antonia Martinez</h5>
                              <p class="card-text">CEO</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div style="background-image: url(https://images.generated.photos/hQALHTE8NNH9rlfw4brIUUfgbda7KWwHW1bg_Zx7sZI/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy90cmFu/c3BhcmVudF92My92/M18wODQzNTc1LnBu/Zw.png)" class="card-img-top poza-card"></div>
                            <div class="card-body">
                              <h5 class="card-title">Liviu Stefan</h5>
                              <p class="card-text">Manager Operatiuni</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card">
                            <div style="background-image: url(https://images.generated.photos/-8WJC5OZkbBCkLdPVOt_4biUcIJJlTwkVEoMQDjEbLY/rs:fit:512:512/wm:0.95:sowe:18:18:0.33/czM6Ly9pY29uczgu/Z3Bob3Rvcy1wcm9k/LnBob3Rvcy90cmFu/c3BhcmVudF92My92/M18wOTE1MTI1LnBu/Zw.png)" class="card-img-top poza-card"></div>
                            <div class="card-body">
                              <h5 class="card-title">Mihai Boss</h5>
                              <p class="card-text">Director General</p>
                            </div>
                        </div>
                    </div>
                </div>
                    
            </div>
        </div>

    </div>
    


    <?php include("includes/footer.php") ?>
